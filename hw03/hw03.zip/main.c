#include <stdio.h>

int numc = 0, cyc = 0, encchar = 0;
float cr;
char inp, a;

int main()
{
  while(scanf("%c", &inp) == 1 && inp > 64)
  {

    cyc++; //počet cyklů ++
    if(cyc == 1)
        a = inp;
    if(a > 90)
    {
        fprintf(stderr,"Error: Neplatny symbol!\n");
        return 100;
        break;
    }

      if(a == inp)
      {
        numc++;
      }
      else
      {
        switch(numc)
        {
          case 1:
            fprintf(stdout,"%c", a);
            numc = 1;
            encchar++;
            break;

          case 2:
            fprintf(stdout,"%c%c", a, a);
            numc = 1;
            encchar = encchar + 2;
            break;

          case 256:
            fprintf(stdout,"%c255%c", a, a);
            encchar = encchar + 5;
            numc = 1;
            break;

          default:
            fprintf(stdout,"%c%d", a, numc);
            if(numc < 10)
              encchar = encchar + 2;
            else if(numc < 100 && numc > 9)
              encchar = encchar + 3;
            else if(numc < 1000 && numc > 99)
              encchar = encchar + 4;
            numc = 1;
            break;
        }
        numc = 1;
      }

      a = inp;

  }
    if (cyc>0)
    {
      switch(numc)
      {
        case 1:
          fprintf(stdout,"%c", a);
          numc = 1;
          encchar++;
          break;

        case 2:
          fprintf(stdout,"%c%c", a, a);
          numc = 1;
          encchar = encchar + 2;
          break;

        case 256:
          fprintf(stdout,"%c255%c", a, a);
          encchar = encchar + 5;
          numc = 1;
          break;

        default:
          fprintf(stdout,"%c%d", a, numc);
          if(numc < 10)
            encchar = encchar + 2;
          else if(numc > 9 && numc < 100)
            encchar = encchar + 3;
          else if(numc > 99 && numc < 1000)
            encchar = encchar + 4;
          numc = 1;
          break;
      }
     //}
    }
  cr = (float)encchar/(float)cyc;
  fprintf(stderr,"Pocet vstupnich symbolu: %i\n", cyc);
  fprintf(stderr,"Pocet zakodovanych symbolu: %i\n", encchar);
  fprintf(stderr,"Kompresni pomer: %.2f\n",cr);
  fprintf(stdout,"\n");
  return 0;
}
